from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from config.database import Base

class ClinicNotification(Base):
    __tablename__ = "clinic_notifications"

    id = Column(Integer, primary_key=True)
    type = Column(String, nullable=False)
    user_id = Column(Integer, ForeignKey("clinic_user.id"), nullable=False)
    appointment_id = Column(Integer, ForeignKey("appointment.id"), nullable=True)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")
    appointment = relationship("Appointment", backref="notifications", uselist=False)