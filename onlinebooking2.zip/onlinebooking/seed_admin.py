# add_admin.py
from config.database import SessionLocal, engine
from models.user import User
from sqlalchemy.exc import IntegrityError

User.metadata.create_all(bind=engine)

def add_admin(email: str, name: str):
    db = SessionLocal()
    try:
        existing_admin = db.query(User).filter(User.email == email).first()
        if existing_admin:
            print(f"⚠️ Admin with email {email} already exists.")
            return
        admin = User(email=email, name=name, role="admin")
        db.add(admin)
        db.commit()
        print(f"✅ Admin '{name}' added successfully!")
    except IntegrityError:
        db.rollback()
        print(f"⚠️ Failed to add admin '{name}'.")
    finally:
        db.close()

# Add admins
add_admin("barangayconnectilhaong@gmail.com", "DentalClinicCtu")
add_admin("geloysoyuc21@gmail.com", "Geloy Cuyos")
