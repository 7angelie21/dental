// =========================================
// 💠 Resident Dashboard Sidebar Toggle
// =========================================
document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.getElementById("sidebar");
  const menuToggle = document.getElementById("menuToggle");
  const overlay = document.getElementById("overlay");

  if (!sidebar || !menuToggle || !overlay) return;

  // Click menu button to toggle sidebar
  menuToggle.addEventListener("click", () => {
    sidebar.classList.toggle("active");
    overlay.classList.toggle("show");
  });

  // Click overlay to close sidebar
  overlay.addEventListener("click", () => {
    sidebar.classList.remove("active");
    overlay.classList.remove("show");
  });

  // ===============================
  // Dynamic sidebar content loader
  // ===============================
  const links = document.querySelectorAll(".menu a[data-section]");
  const main = document.getElementById("main-content");

  if (links.length > 0 && main) {
    links.forEach(link => {
      link.addEventListener("click", async (e) => {
        e.preventDefault();

        const section = link.dataset.section;
        if (!section) return;

        try {
          const res = await fetch(`/dashboard/${section}`);
          if (!res.ok) throw new Error("Failed loading section.");

          const html = await res.text();
          main.innerHTML = html;

        } catch (err) {
          main.innerHTML = `
            <p style="color:red; padding:10px;">
              Error loading <strong>${section}</strong>: ${err.message}
            </p>
          `;
        }
      });
    });
  }
});
