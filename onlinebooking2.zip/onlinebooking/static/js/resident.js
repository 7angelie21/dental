// =========================================
// 💠 Resident Dashboard Script (with fade fix)
// =========================================
document.addEventListener("DOMContentLoaded", async function () {
  const sidebar = document.getElementById("sidebar");
  const menuToggle = document.getElementById("menuToggle");
  const overlay = document.getElementById("overlay");

  // Sidebar toggle
  menuToggle.addEventListener("click", () => {
    sidebar.classList.toggle("active");
    overlay.classList.toggle("show");
  });
  overlay.addEventListener("click", () => {
    sidebar.classList.remove("active");
    overlay.classList.remove("show");
  });

  // ===============================
  // 🕒 Date + Time Display
  // ===============================
  function updateDateTime() {
    const now = new Date();
    document.getElementById("dateDisplay").textContent = now.toLocaleDateString("en-US", {
      weekday: "long", year: "numeric", month: "long", day: "numeric"
    });
    document.getElementById("timeDisplay").textContent = now.toLocaleTimeString("en-US", {
      hour: "2-digit", minute: "2-digit", second: "2-digit"
    });
  }
  updateDateTime();
  setInterval(updateDateTime, 1000);

  // ===============================
  // 📦 Fetch Appointments
  // ===============================
  let appointmentsData = [];
  try {
    const res = await fetch("/appointment/all");
    if (res.ok) {
      appointmentsData = await res.json();
      appointmentsData.sort((a, b) => {
        const aTime = new Date(a.updated_at || a.created_at || 0);
        const bTime = new Date(b.updated_at || b.created_at || 0);
        return bTime - aTime;
      });
    }
  } catch (err) {
    console.error("❌ Failed to fetch appointments:", err);
  }

  // ===============================
  // 🎨 Status Styles
  // ===============================
  const STATUS = {
    pending: { icon: "ⓘ", label: "Pending" },
    accepted: { icon: "✔", label: "Accepted" },
    rejected: { icon: "✘", label: "Rejected" },
    rescheduled: { icon: "↻", label: "Rescheduled" },
    completed: { icon: "✦", label: "Completed" },
    cancelled: { icon: "✘", label: "Cancelled" },
  };

  // ===============================
  // 🦷 Render Appointment Cards
  // ===============================
  const list = document.getElementById("appointmentList");

  function renderAppointments(data) {
    list.innerHTML = "";
    if (!data.length) {
      list.innerHTML = `<li><small>No appointments yet.</small></li>`;
      return;
    }

    data.forEach((a) => {
      const status = (a.status || "pending").toLowerCase();
      const style = STATUS[status] || STATUS.pending;
      const dateVal = a.date_time || a.start;

      const li = document.createElement("li");
      li.className = "fade-out";
      li.innerHTML = `
        <a href="/appointment/details/${a.id}" class="appt-link">
          <strong>${a.title}</strong>
          <div class="appointment-meta">
            <small>${new Date(dateVal).toLocaleString("en-US", {
              year: "numeric", month: "short", day: "numeric",
              hour: "2-digit", minute: "2-digit"
            })}</small>
            <span class="badge ${status}">
              ${style.icon} ${style.label}
            </span>
          </div>
        </a>
      `;
      list.appendChild(li);
      setTimeout(() => li.classList.add("visible"), 60);
    });

    applyPagination();
  }

  renderAppointments(appointmentsData);

  // ===============================
  // 📄 Pagination Logic
  // ===============================
  function applyPagination() {
    const items = Array.from(list.children);
    const ITEMS_PER_PAGE = 5;
    let currentPage = 1;
    const totalPages = Math.ceil(items.length / ITEMS_PER_PAGE);
    const prev = document.getElementById("prevPage");
    const next = document.getElementById("nextPage");
    const indicator = document.getElementById("pageIndicator");
    const wrapper = document.querySelector(".pagination");

    function renderPage() {
      items.forEach((item, i) => {
        const show = i >= (currentPage - 1) * ITEMS_PER_PAGE && i < currentPage * ITEMS_PER_PAGE;
        item.style.display = show ? "block" : "none";
      });
      indicator.textContent = `Page ${currentPage} of ${totalPages}`;
      prev.disabled = currentPage === 1;
      next.disabled = currentPage === totalPages;
      wrapper.style.display = totalPages <= 1 ? "none" : "flex";
    }

    prev.addEventListener("click", () => {
      if (currentPage > 1) { currentPage--; renderPage(); }
    });
    next.addEventListener("click", () => {
      if (currentPage < totalPages) { currentPage++; renderPage(); }
    });

    renderPage();
  }

  // ===============================
  // 🩺 Calendar Availability
  // ===============================
  const cal = new FullCalendar.Calendar(document.getElementById("calendar"), {
    initialView: "dayGridMonth",
    headerToolbar: { left: "prev,next today", center: "title", right: "" },

    // ⭐ FIX: Hide slot text for past dates ⭐
    eventContent: function (arg) {
      const today = new Date().toISOString().split("T")[0];

      if (arg.event.startStr < today) {
        return { html: "" }; // hide text (blank)
      }

      return { html: `<span>${arg.event.title}</span>` };
    },

    datesSet: () => loadAvailability(cal),
  });

  cal.render();

  async function loadAvailability(calendar) {
    const start = calendar.view.currentStart;
    const end = calendar.view.currentEnd;
    const dates = [];
    const current = new Date(start);
    while (current <= end) {
      dates.push(current.toISOString().split("T")[0]);
      current.setDate(current.getDate() + 1);
    }

    const results = await Promise.all(dates.map(async (iso) => {
      try {
        const r = await fetch(`/appointment/availability?date=${iso}`);
        return { date: iso, data: await r.json() };
      } catch { return { date: iso, data: null }; }
    }));

    const events = [];
    const todayISO = new Date().toISOString().split("T")[0];

    for (const { date, data } of results) {
      if (!data) continue;

      // Skip past dates (no text, no background)
      if (date < todayISO) continue;

      if (data.status === "unavailable") {
        events.push({
          title: "",
          start: date,
          display: "background",
          backgroundColor: "#fca5a5"
        });
      } else {
        const count = data.available_slots.length;
        events.push({
          title: `${count} slots`,
          start: date,
          backgroundColor: "#e0fce0",
          borderColor: "#22c55e",
          textColor: "#14532d",
        });
      }
    }

    calendar.removeAllEvents();
    calendar.addEventSource(events);
  }

  // ===============================
  // 🔔 Notifications Modal
  // ===============================
  async function loadNotifications() {
    try {
      const r = await fetch("/appointment/notifications");
      const d = await r.json();
      const c = document.getElementById("notifCount");
      if (d.count > 0) {
        c.textContent = d.count > 9 ? "9+" : d.count;
        c.style.display = "block";
      } else c.style.display = "none";
      window.notifications = d.notifications || [];
    } catch (e) {
      console.error("Notif load error:", e);
    }
  }

  async function markNotificationsAsRead() {
    await fetch("/appointment/notifications/mark-read", { method: "POST" });
    document.getElementById("notifCount").style.display = "none";
  }

  document.getElementById("notifBell").addEventListener("click", () => {
    const modal = document.getElementById("notifModal");
    const list = document.getElementById("notifList");
    modal.classList.add("show");
    markNotificationsAsRead();
    list.innerHTML = "";

    if (window.notifications?.length) {
      window.notifications.forEach((n) => {
        const cls = n.status === "accepted" ? "accepted" :
                    n.status === "rescheduled" ? "rescheduled" :
                    n.status === "cancelled" ? "cancelled" : "";
        const card = document.createElement("div");
        card.className = "notif-card";
        card.innerHTML = `
          <div class="notif-title">${n.title}</div>
          <span class="notif-tag ${cls}">${n.status.charAt(0).toUpperCase() + n.status.slice(1)}</span>
          <div class="notif-msg">${n.message}</div>
          <div class="notif-time">${n.time}</div>
          <a href="/appointment/details/${n.id}" class="notif-link">View Details →</a>
        `;
        list.appendChild(card);
      });
    } else {
      list.innerHTML = `<p class="empty-msg">No new notifications.</p>`;
    }
  });

  document.getElementById("notifClose").addEventListener("click", () => {
    document.getElementById("notifModal").classList.remove("show");
  });
  window.addEventListener("click", (e) => {
    const modal = document.getElementById("notifModal");
    if (e.target === modal) modal.classList.remove("show");
  });

  loadNotifications();
});
