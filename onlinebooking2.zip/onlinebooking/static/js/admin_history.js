document.addEventListener("DOMContentLoaded", () => {
    const showMoreBtn = document.getElementById("show-more-btn");
    if (!showMoreBtn) return;

    showMoreBtn.addEventListener("click", async () => {
        const offset = showMoreBtn.dataset.offset;
        const limit = showMoreBtn.dataset.limit;

        const response = await fetch(`/admin/history?offset=${offset}&limit=${limit}`, {
            headers: { "X-Requested-With": "XMLHttpRequest" }
        });

        const data = await response.json();

        const tbody = document.getElementById("history-tbody");
        tbody.insertAdjacentHTML("beforeend", data.rows_html);

        // Update offset for next batch
        const newOffset = data.next_offset;
        showMoreBtn.dataset.offset = newOffset;

        // Hide button if all rows loaded
        if (newOffset >= data.total_count) {
            showMoreBtn.style.display = "none";
        }
    });
});
