// ===========================
// 💠 appointment.js (FINAL WORKING VERSION)
// ===========================

const TIMES = [
  { start: "08:00", end: "09:00" },
  { start: "09:00", end: "10:00" },
  { start: "10:00", end: "11:00" },
  { start: "11:00", end: "12:00" },
  { start: "13:00", end: "14:00" },
  { start: "14:00", end: "15:00" },
  { start: "15:00", end: "16:00" },
  { start: "16:00", end: "17:00" },
];

// Format range for dropdown labels
function formatTimeRange(start, end) {
  const toLabel = (t) => {
    const [h, m] = t.split(":").map(Number);
    const d = new Date();
    d.setHours(h, m, 0, 0);
    return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  };
  return `${toLabel(start)} – ${toLabel(end)}`;
}

// ✅ Combine date + time into hidden ISO field for backend
function combineDateTime() {
  const date = document.getElementById("appointment_date").value;
  const time = document.getElementById("appointment_time").value;
  const hidden = document.getElementById("date_time");
  hidden.value = date && time ? `${date}T${time}` : "";
}

// ✅ Fetch booked slots from backend
async function fetchBookedSlots(date) {
  try {
    const res = await fetch(`/appointment/availability?date=${date}`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.booked || [];
  } catch (err) {
    console.error("Error fetching booked slots:", err);
    return [];
  }
}

// ✅ Populate dropdown dynamically
async function populateTimeDropdown() {
  const dateInput = document.getElementById("appointment_date");
  const timeSelect = document.getElementById("appointment_time");
  const date = dateInput.value;
  timeSelect.innerHTML = `<option value="">Loading...</option>`;

  if (!date) {
    timeSelect.innerHTML = `<option value="">-- Select a date first --</option>`;
    return;
  }

  // Fetch booked slots
  const booked = await fetchBookedSlots(date);
  const now = new Date();
  const todayStr = now.toISOString().split("T")[0];
  const isToday = date === todayStr;

  timeSelect.innerHTML = `<option value="">-- Select a time --</option>`;
  TIMES.forEach((slot) => {
    const option = document.createElement("option");
    option.value = slot.start;
    option.textContent = formatTimeRange(slot.start, slot.end);

    const isBooked = booked.includes(slot.start);
    if (isBooked) {
      option.disabled = true;
      option.textContent += " (Unavailable)";
    } else if (isToday) {
      const slotDate = new Date(`${date}T${slot.start}`);
      if (slotDate < now) {
        option.disabled = true;
        option.textContent += " (Past)";
      }
    }

    timeSelect.appendChild(option);
  });
}

// ===========================
// 🚀 Initialize everything
// ===========================
document.addEventListener("DOMContentLoaded", () => {
  const dateInput = document.getElementById("appointment_date");
  const form = document.getElementById("appointmentForm");

  // Restrict past dates
  const today = new Date();
  dateInput.min = today.toISOString().split("T")[0];

  // When selecting date → populate available times
  dateInput.addEventListener("change", populateTimeDropdown);

  // Populate once on load
  populateTimeDropdown();

  // ✅ Automatically combine date/time and submit directly
  form.addEventListener("submit", (event) => {
    event.preventDefault(); // stop browser from submitting first
    combineDateTime();
    form.submit(); // now manually submit once ready
  });

// ===========================
// 💠 appointment.js — Alert handler
// ===========================

function showAlertFromCookies() {
  const cookies = document.cookie.split(";").reduce((acc, cur) => {
    const [k, v] = cur.trim().split("=");
    acc[k] = decodeURIComponent(v || "");
    return acc;
  }, {});

  const msg = cookies.error || cookies.success;
  if (msg) {
    alert(msg);
    // ✅ Clear cookies after showing
    document.cookie = "error=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    document.cookie = "success=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  showAlertFromCookies(); // ✅ run once on page load
});



});
