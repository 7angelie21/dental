// ================= MODALS =================
let currentRequestId = null;
let currentAction = null;

function openRescheduleModal(requestId) {
  currentRequestId = requestId;
  const modal = document.getElementById("rescheduleModal");
  modal.style.display = "flex";

  const form = document.getElementById("rescheduleForm");
  form.reset();

  populateTimeDropdown();

  const dateInput = document.getElementById("appointment_date");
  const timeSelect = document.getElementById("appointment_time");

  dateInput.onchange = populateTimeDropdown;
  timeSelect.onchange = combineDateTime;

  form.onsubmit = async (e) => {
    e.preventDefault();
    combineDateTime();

    const date = dateInput.value;
    const time = timeSelect.value;

    if (!date || !time) {
      alert("Please select a valid date and time!");
      return;
    }

    modal.style.display = "none";

    await fetchAction(currentRequestId, "reschedule", { newDate: date, newTime: time });

    const row = document.querySelector(`tr[data-id='${currentRequestId}']`);
    if (row) {
      row.querySelector("td:nth-child(3)").textContent = `${date} ${time}`;
      row.querySelector("td:last-child").innerHTML = `
        <select class="action-dropdown" data-id="${currentRequestId}">
          <option value="">Select action</option>
          <option value="finish">Finish</option>
        </select>`;
    }
  };
}

function closeRescheduleModal() {
  document.getElementById("rescheduleModal").style.display = "none";
}

function openConfirmationModal(action, requestId) {
  currentRequestId = requestId;
  currentAction = action;
  const modal = document.getElementById("confirmationModal");
  const text = document.getElementById("confirmationText");
  const confirmBtn = document.getElementById("confirmBtn");

  let message = "";
  if (action === "approve") message = "Are you sure you want to approve this request?";
  else if (action === "reject") message = "Are you sure you want to reject this request?";
  else if (action === "finish") message = "Mark this appointment as finished?";

  text.innerText = message;
  modal.style.display = "flex";

  confirmBtn.onclick = async () => {
    modal.style.display = "none";
    await fetchAction(requestId, action);
  };
}

function closeConfirmationModal() {
  document.getElementById("confirmationModal").style.display = "none";
}

function showSuccessMessage(msg, isError = false) {
  const modal = document.getElementById("successModal");
  const text = document.getElementById("successText");
  text.innerText = msg;
  text.style.color = isError ? "red" : "green";
  modal.style.display = "flex";
}

function closeSuccessModal() {
  document.getElementById("successModal").style.display = "none";
}

// ================= DROPDOWN ACTIONS =================
document.addEventListener("change", (e) => {
  const dropdown = e.target;
  if (!dropdown.classList.contains("action-dropdown")) return;

  const action = dropdown.value;
  const requestId = parseInt(dropdown.dataset.id);
  if (!action) return;

  dropdown.value = "";

  if (action === "reschedule") openRescheduleModal(requestId);
  else openConfirmationModal(action, requestId);
});

// ================= FETCH ACTIONS =================
async function fetchAction(requestId, action, rescheduleData = null) {
  try {
    let url = `/admin/request/${requestId}/${action}`;
    let options = { method: "POST" };

    if (rescheduleData) {
      options.headers = { "Content-Type": "application/json" };
      options.body = JSON.stringify(rescheduleData);
    }

    const res = await fetch(url, options);
    const data = await res.json();

    const row = document.querySelector(`tr[data-id='${requestId}']`);
    if (!row) return;

    const badge = row.querySelector(".badge");
    const actionCell = row.querySelector("td:last-child");

    switch(action){
      case "approve":
        badge.innerText = "Approved";
        badge.className = "badge approved";
        actionCell.innerHTML = `
          <select class="action-dropdown" data-id="${requestId}">
            <option value="">Select action</option>
            <option value="finish">Finish</option>
          </select>`;
        break;
      case "reschedule":
        badge.innerText = "Rescheduled";
        badge.className = "badge rescheduled";
        actionCell.innerHTML = `
          <select class="action-dropdown" data-id="${requestId}">
            <option value="">Select action</option>
            <option value="finish">Finish</option>
          </select>`;
        break;
      case "finish":
        badge.innerText = "Completed";
        badge.className = "badge completed";
        row.remove();
        break;
      case "reject":
        badge.innerText = "Rejected";
        badge.className = "badge rejected";
        row.remove();
        break;
    }

    showSuccessMessage(`Request ${data.status} successfully!`);
  } catch (err) {
    console.error(err);
    showSuccessMessage(`Failed to ${action} request.`, true);
  }
}

// ================= TIME DROPDOWN HELPERS =================
const TIMES = [
  { start: "08:00", end: "09:00" },
  { start: "09:00", end: "10:00" },
  { start: "10:00", end: "11:00" },
  { start: "11:00", end: "12:00" },
  { start: "13:00", end: "14:00" },
  { start: "14:00", end: "15:00" },
  { start: "15:00", end: "16:00" },
  { start: "16:00", end: "17:00" },
];

function combineDateTime() {
  const date = document.getElementById("appointment_date").value;
  const time = document.getElementById("appointment_time").value;
  const hidden = document.getElementById("date_time");
  hidden.value = date && time ? `${date}T${time}` : "";
}

async function fetchBookedSlots(date) {
  try {
    const res = await fetch(`/appointment/availability?date=${date}`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.booked || [];
  } catch (err) {
    console.error(err);
    return [];
  }
}

async function populateTimeDropdown() {
  const dateInput = document.getElementById("appointment_date");
  const timeSelect = document.getElementById("appointment_time");
  const date = dateInput.value;

  timeSelect.innerHTML = `<option value="">Loading...</option>`;
  if (!date) {
    timeSelect.innerHTML = `<option value="">-- Select a date first --</option>`;
    return;
  }

  const booked = await fetchBookedSlots(date);
  const now = new Date();
  const todayStr = now.toISOString().split("T")[0];
  const isToday = date === todayStr;

  timeSelect.innerHTML = `<option value="">-- Select a time --</option>`;
  TIMES.forEach(slot => {
    const option = document.createElement("option");
    option.value = slot.start;
    option.textContent = `${slot.start} - ${slot.end}`;

    const slotDate = new Date(`${date}T${slot.start}`);
    if (booked.includes(slot.start) || (isToday && slotDate < now)) {
      option.disabled = true;
      option.textContent += " (Unavailable)";
    }

    timeSelect.appendChild(option);
  });
}

// ================= CLOSE MODALS WHEN CLICKING OUTSIDE =================
window.onclick = (event) => {
  ["confirmationModal","rescheduleModal","successModal"].forEach(id => {
    const modal = document.getElementById(id);
    if (event.target === modal) modal.style.display = "none";
  });
};
