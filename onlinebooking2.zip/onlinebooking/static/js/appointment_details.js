// =====================================
// 🔁 Reschedule Modal — Smart Slot Loader
// =====================================
const dateEl = document.getElementById("new_date");
const timeEl = document.getElementById("new_time");

if (dateEl && timeEl) {
  // 🧭 Block past dates
  const todayISO = new Date().toISOString().split("T")[0];
  dateEl.min = todayISO;

  timeEl.disabled = true;

  // Convert 24h → 12h
  const to12Hour = (t) => {
    const [h, m] = t.split(":").map(Number);
    const period = h >= 12 ? "PM" : "AM";
    const hour12 = ((h + 11) % 12) + 1;
    return `${hour12}:${String(m).padStart(2, "0")} ${period}`;
  };

  const formatRange = (start) => {
    const endH = parseInt(start.split(":")[0]) + 1;
    const end = `${String(endH).padStart(2, "0")}:00`;
    return `${to12Hour(start)} – ${to12Hour(end)}`;
  };

  dateEl.addEventListener("change", async () => {
    const d = dateEl.value;
    timeEl.innerHTML = `<option value="">Loading…</option>`;
    timeEl.disabled = true;

    if (!d) return;

    try {
      const res = await fetch(`/appointment/availability?date=${encodeURIComponent(d)}`);
      const data = await res.json();

      // 🟥 Dentist unavailable
      if (data.status === "unavailable") {
        timeEl.innerHTML = `<option value="">Dentist unavailable this day</option>`;
        return;
      }

      const allSlots = ["08:00","09:00","10:00","11:00","13:00","14:00","15:00","16:00"];
      const available = data.available_slots || [];
      const booked = data.booked_slots || [];
      const now = new Date();
      const today = new Date().toISOString().split("T")[0];

      const opts = [`<option value="">-- Select a time --</option>`];

      allSlots.forEach(slot => {
        const label = formatRange(slot);
        const slotDate = new Date(`${d}T${slot}`);

        if (d === today && slotDate < now) {
          opts.push(`<option value="" disabled>${label} (Past)</option>`);
        } else if (booked.includes(slot)) {
          opts.push(`<option value="" disabled>${label} (Booked)</option>`);
        } else if (available.includes(slot)) {
          opts.push(`<option value="${slot}">${label}</option>`);
        }
      });

      timeEl.innerHTML = opts.join("");
      timeEl.disabled = false;

    } catch (err) {
      console.error("Failed to load availability:", err);
      timeEl.innerHTML = `<option value="">Failed to load slots</option>`;
    }
  });
}
