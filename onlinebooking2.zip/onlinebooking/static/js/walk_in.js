document.addEventListener("DOMContentLoaded", async function () {
  const sidebar = document.getElementById("sidebar");
  const menuToggle = document.getElementById("menuToggle");
  const overlay = document.getElementById("overlay");

  menuToggle.addEventListener("click", () => {
    sidebar.classList.toggle("active");
    overlay.classList.toggle("show");
  });
  overlay.addEventListener("click", () => {
    sidebar.classList.remove("active");
    overlay.classList.remove("show");
  });

  // ================= TIME SLOTS =================
  const TIMES = [
    { start: "08:00", end: "09:00" },
    { start: "09:00", end: "10:00" },
    { start: "10:00", end: "11:00" },
    { start: "11:00", end: "12:00" },
    { start: "13:00", end: "14:00" },
    { start: "14:00", end: "15:00" },
    { start: "15:00", end: "16:00" },
    { start: "16:00", end: "17:00" },
  ];

  function formatTimeTo12Hour(t) {
    let [h, m] = t.split(":").map(Number);
    const ampm = h >= 12 ? "PM" : "AM";
    h = h % 12 || 12;
    return `${h}:${m.toString().padStart(2, "0")} ${ampm}`;
  }

  function formatTimeRange(start, end) {
    return `${formatTimeTo12Hour(start)} – ${formatTimeTo12Hour(end)}`;
  }

  function formatDateToMMDDYYYY(dateStr) {
    const [year, month, day] = dateStr.split("-");
    return `${month}/${day}/${year}`;
  }

  // ✅ Set hidden input in exact format backend expects
  function setHiddenDateTime() {
    const dateInput = document.getElementById("appointment_date").value;
    const timeSelect = document.getElementById("appointment_time").value;
    const hiddenInput = document.getElementById("date_time");

    if (!dateInput || !timeSelect) return;

    const [hour24, minute] = timeSelect.split(":").map(Number);
    const ampm = hour24 >= 12 ? "PM" : "AM";
    const hour12 = hour24 % 12 || 12;

    // ⚡ Ensure exactly "MM/DD/YYYY HH:MM AM/PM"
    hiddenInput.value = `${formatDateToMMDDYYYY(dateInput)} ${hour12}:${minute.toString().padStart(2, "0")} ${ampm}`;
  }

  async function fetchBookedSlots(date) {
    try {
      const res = await fetch(`/appointment/availability?date=${date}`);
      if (!res.ok) return [];
      const data = await res.json();
      return data.booked || [];
    } catch (err) {
      console.error(err);
      return [];
    }
  }

  async function populateTimeDropdown() {
    const dateInput = document.getElementById("appointment_date");
    const timeSelect = document.getElementById("appointment_time");
    const displayDate = document.getElementById("displayDate");
    const date = dateInput.value;
    displayDate.textContent = date ? formatDateToMMDDYYYY(date) : "";
    timeSelect.innerHTML = `<option value="">-- Select a time --</option>`;
    if (!date) return;

    const booked = await fetchBookedSlots(date);
    const now = new Date();
    const isToday = date === now.toISOString().split("T")[0];

    TIMES.forEach(slot => {
      const option = document.createElement("option");
      option.value = slot.start; // 24-hour format
      option.textContent = formatTimeRange(slot.start, slot.end);

      const slotDate = new Date(`${date}T${slot.start}`);
      if (booked.includes(slot.start)) {
        option.disabled = true;
        option.textContent += " (Unavailable)";
      } else if (isToday && slotDate < now) {
        option.disabled = true;
        option.textContent += " (Past)";
      }

      timeSelect.appendChild(option);
    });

    setHiddenDateTime();
  }

  const dateInput = document.getElementById("appointment_date");
  const timeSelect = document.getElementById("appointment_time");
  const form = document.getElementById("appointmentForm");

  // Restrict past dates
  dateInput.min = new Date().toISOString().split("T")[0];

  dateInput.addEventListener("change", populateTimeDropdown);
  timeSelect.addEventListener("change", setHiddenDateTime);

  form.addEventListener("submit", e => {
    e.preventDefault();
    setHiddenDateTime(); // ⚡ ensures correct format
    form.submit();
  });

  if (dateInput.value) populateTimeDropdown();
});
