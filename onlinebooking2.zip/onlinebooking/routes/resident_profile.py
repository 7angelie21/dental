from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from config.database import SessionLocal  # DB session
from models.user import User  # ✅ Use the correct model
from models.appointment import Appointment

router = APIRouter()
templates = Jinja2Templates(directory="templates")

# ✅ Database Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/resident/{resident_id}")
def resident_profile(request: Request, resident_id: int, db: Session = Depends(get_db)):
    # ✅ Get the resident by ID using User model (role = "resident")
    resident = db.query(User).filter(User.id == resident_id, User.role == "resident").first()
    
    if not resident:
        raise HTTPException(status_code=404, detail="Resident not found")

    # ✅ Fetch this person's booking history
    appointments = db.query(Appointment).filter(Appointment.resident_email == resident.email).all()

    return templates.TemplateResponse("resident_profile.html", {
        "request": request,
        "resident": resident,
        "appointments": appointments
    })
