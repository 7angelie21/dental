from fastapi import APIRouter, Request, Form, status
from fastapi.responses import RedirectResponse, HTMLResponse
from authlib.integrations.starlette_client import OAuth
from config.database import SessionLocal
from models.user import User
from models import User, ClinicNotification
import os
from dotenv import load_dotenv
from passlib.context import CryptContext

load_dotenv(".env")

router = APIRouter(prefix="/auth", tags=["Authentication"])

# --- OAuth Setup ---
oauth = OAuth()
oauth.register(
    name="google",
    client_id=os.getenv("GOOGLE_CLIENT_ID"),
    client_secret=os.getenv("GOOGLE_CLIENT_SECRET"),
    server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
    client_kwargs={"scope": "openid email profile"},
)

# --- Password hashing setup ---
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# -------------------- Google OAuth --------------------
@router.get("/login")
async def login_via_google(request: Request):
    return await oauth.google.authorize_redirect(request, os.getenv("GOOGLE_REDIRECT_URI"))

@router.get("/callback")
async def auth_callback(request: Request):
    token = await oauth.google.authorize_access_token(request)
    resp = await oauth.google.get("userinfo", token=token)
    user_info = resp.json()

    if not user_info:
        return HTMLResponse("Failed to get user info", status_code=400)

    db = SessionLocal()
    try:
        user = db.query(User).filter(User.email == user_info["email"]).first()

        if not user:
            # --- Create new resident ---
            new_user = User(
                email=user_info["email"],
                name=user_info["name"],
                role="resident",
                picture=user_info.get("picture")
            )
            db.add(new_user)
            db.commit()
            db.refresh(new_user)
            user = new_user

            # --- Create notification for admin ---
            notif = ClinicNotification(
                type="new_user",
                user_id=new_user.id,  # optionally admin_id if desired
                is_read=False
            )
            db.add(notif)
            db.commit()
        else:
            # --- Update existing user's picture ---
            user.picture = user_info.get("picture")
            db.commit()

        # --- Save session ---
        request.session["email"] = user.email
    finally:
        db.close()

    return RedirectResponse(url="/dashboard")

# -------------------- Existing Account Login Form --------------------
@router.get("/existing-account", response_class=HTMLResponse)
async def existing_account_form():
    return """
    <html>
    <head>
        <title>Login to Existing Account</title>
        <link rel="stylesheet" href="/static/css/style.css">
    </head>
    <body>
        <div class="container">
            <img src="/static/img/dental logo.png" alt="Dental Clinic" class="logo">
            <h2>Login to Existing Account</h2>
            <form action="/auth/existing-account" method="post">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
        </div>
    </body>
    </html>
    """

# -------------------- Handle Existing Account Login --------------------
@router.post("/existing-account")
async def existing_account_login(request: Request, email: str = Form(...), password: str = Form(...)):
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.email == email).first()
        if not user:
            return HTMLResponse("Invalid email or password", status_code=status.HTTP_401_UNAUTHORIZED)

        # Verify password using hashed password
        if not pwd_context.verify(password, user.password):
            return HTMLResponse("Invalid email or password", status_code=status.HTTP_401_UNAUTHORIZED)

        request.session["email"] = user.email
    finally:
        db.close()

    return RedirectResponse(url="/dashboard")
