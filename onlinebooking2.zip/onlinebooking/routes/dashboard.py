from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import desc

from config.database import SessionLocal
from models.user import User
from models.appointment import Appointment

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])
templates = Jinja2Templates(directory="templates")

# ✅ Database dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ============================
# 🔹 Dashboard (Admin & Resident)
# ============================
@router.get("/", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db)):
    email = request.session.get("email")
    if not email:
        return RedirectResponse(url="/", status_code=302)

    user = db.query(User).filter(User.email == email).first()
    if not user:
        return HTMLResponse("⚠ User not found", status_code=404)

    if user.role == "admin":
        # Admin sees all appointments and residents
        appointments = db.query(Appointment).order_by(desc(Appointment.date_time)).all()
        residents = db.query(User).filter(User.role == "resident").all()
        template_name = "admin_dashboard.html"
    else:
        # Resident sees only own appointments
        appointments = (
            db.query(Appointment)
            .filter(Appointment.resident_email == user.email)
            .order_by(desc(Appointment.date_time))
            .all()
        )
        residents = None
        template_name = "resident_dashboard.html"

    # Prepare appointments for frontend
    color_map = {
        "pending": "#ef4444",
        "accepted": "#3b82f6",
        "approved": "#22c55e",
        "rejected": "#9ca3af",
        "completed": "#10b981",
        "reschedule": "#f59e0b",
    }

    appointments_data = [
        {
            "title": appt.title,
            "date_time": appt.date_time.isoformat() if appt.date_time else "",
            "status": getattr(appt, "status", "pending"),
            "color": color_map.get(getattr(appt, "status", "pending").lower(), "#ef4444"),
            "email": getattr(appt, "resident_email", ""),
        }
        for appt in appointments
    ]

    return templates.TemplateResponse(
        template_name,
        {
            "request": request,
            "user": user,
            "appointments": appointments_data,
            "residents": residents,
        },
    )


# ============================
# 🔹 Appointment History
# ============================
@router.get("/history", response_class=HTMLResponse)
def history_page(request: Request, db: Session = Depends(get_db)):
    email = request.session.get("email")
    if not email:
        return HTMLResponse("<h2>Please log in first.</h2>", status_code=401)

    user = db.query(User).filter(User.email == email).first()
    if not user:
        return HTMLResponse("User not found", status_code=404)

    history = (
        db.query(Appointment)
        .filter(
            Appointment.resident_email == user.email,
            Appointment.status.in_(["cancelled", "completed", "rejected"]),
        )
        .order_by(desc(Appointment.date_time))
        .all()
    )

    return templates.TemplateResponse(
        "history.html",
        {"request": request, "user": user, "appointments": history},
    )
