from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from config.database import SessionLocal
from models.appointment import Appointment
from models.user import User
from datetime import datetime, timedelta
from models.availability import DentistAvailability
from sqlalchemy import desc
from fastapi import HTTPException


router = APIRouter(prefix="/appointment", tags=["Appointment"])
templates = Jinja2Templates(directory="templates")


# ============================
# 🔹 Database dependency
# ============================
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ============================
# 🔹 Show appointment request form
# ============================
@router.get("/request", response_class=HTMLResponse)
def appointment_form(request: Request):

    from_submit = request.query_params.get("from_submit")

    if not from_submit:
        request.session.pop("flash_message", None)
        request.session.pop("flash_type", None)

    message = request.session.pop("flash_message", None)
    message_type = request.session.pop("flash_type", None)

    return templates.TemplateResponse(
        "appointment.html",
        {"request": request, "message": message, "message_type": message_type},
    )


# ============================
# 🔹 Submit appointment request
# ============================
@router.post("/request")
def submit_appointment(
    request: Request,
    title: str = Form(...),
    date_time: str = Form(...),
    db: Session = Depends(get_db),
):
    email = request.session.get("email")
    if not email:
        return RedirectResponse(url="/", status_code=303)

    user = db.query(User).filter(User.email == email).first()
    if not user:
        return RedirectResponse(url="/", status_code=303)

    selected_datetime = datetime.fromisoformat(date_time)
    selected_date = selected_datetime.date()

    dentist_unavailable = (
        db.query(DentistAvailability)
        .filter(
            DentistAvailability.date == selected_date,
            DentistAvailability.is_available == False,
        )
        .first()
    )
    if dentist_unavailable:
        request.session["flash_message"] = (
            "❌ The dentist is not available on this day. Please choose another date."
        )
        request.session["flash_type"] = "error"
        return RedirectResponse(
            url="/appointment/request?from_submit=true", status_code=303
        )

    existing = (
        db.query(Appointment)
        .filter(
            Appointment.date_time == selected_datetime,
            Appointment.status.notin_(["cancelled", "rejected"]),
        )
        .first()
    )
    if existing:
        request.session["flash_message"] = "⚠️ That time slot is already booked."
        request.session["flash_type"] = "warning"
        return RedirectResponse(
            url="/appointment/request?from_submit=true", status_code=303
        )

    new_appointment = Appointment(
        title=title,
        date_time=selected_datetime,
        status="pending",
        resident_email=email,
        resident_name=user.name,
    )
    new_appointment.updated_at = datetime.utcnow()
    db.add(new_appointment)
    db.commit()

    request.session["flash_message"] = "✅ Appointment successfully booked!"
    request.session["flash_type"] = "success"
    return RedirectResponse(url="/appointment/request?from_submit=true", status_code=303)


# ============================
# 🔹 Resident Dashboard
# ============================
@router.get("/dashboard", response_class=HTMLResponse)
def resident_dashboard(request: Request, db: Session = Depends(get_db)):
    email = request.session.get("email")
    if not email:
        return RedirectResponse(url="/", status_code=303)

    appointments = (
        db.query(Appointment)
        .filter(Appointment.resident_email == email)
        .order_by(desc(Appointment.updated_at), desc(Appointment.created_at))
        .all()
    )

    appointments_data = [
        {
            "id": a.id,
            "title": a.title,
            "start": a.date_time.isoformat(),
            "end": a.date_time.isoformat(),
            "status": a.status,
        }
        for a in appointments
    ]

    return templates.TemplateResponse(
        "resident_dashboard.html", {"request": request, "appointments": appointments_data}
    )


# ============================
# 🔹 Availability
# ============================
@router.get("/availability")
def get_available_slots(date: str, db: Session = Depends(get_db)):

    try:
        target = datetime.strptime(date, "%Y-%m-%d").date()
    except ValueError:
        return JSONResponse({"status": "error", "message": "Invalid date"}, status_code=400)

    dentist_rest = (
        db.query(DentistAvailability)
        .filter(DentistAvailability.date == target, DentistAvailability.is_available == False)
        .first()
    )
    if dentist_rest:
        return {"status": "unavailable", "available_slots": [], "booked_slots": [], "booked": []}

    SLOT_STARTS = ["08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]
    start_day = datetime.combine(target, datetime.min.time())
    end_day = start_day + timedelta(days=1)

    appointments = (
        db.query(Appointment)
        .filter(
            Appointment.date_time >= start_day,
            Appointment.date_time < end_day,
            Appointment.status.notin_(["cancelled", "rejected"]),
        )
        .all()
    )
    booked_starts = {a.date_time.strftime("%H:%M") for a in appointments}

    available_slots = [s for s in SLOT_STARTS if s not in booked_starts]
    booked_slots = [s for s in SLOT_STARTS if s in booked_starts]

    return {
        "status": "available",
        "available_slots": available_slots,
        "booked_slots": booked_slots,
        "booked": booked_slots,
    }


# ============================
# 🔹 Fetch all appointments (dashboard data)
# ============================
@router.get("/all")
def get_all_appointments(request: Request, db: Session = Depends(get_db)):

    email = request.session.get("email")
    if not email:
        return JSONResponse({"error": "Not logged in"}, status_code=401)

    appointments = (
        db.query(Appointment)
        .filter(Appointment.resident_email == email)
        .order_by(desc(Appointment.updated_at), desc(Appointment.created_at))
        .all()
    )

    return [
        {
            "id": a.id,
            "title": a.title,
            "start": a.date_time.isoformat(),
            "end": a.date_time.isoformat(),
            "status": a.status,
            "updated_at": a.updated_at.isoformat() if a.updated_at else None,
            "last_action": a.last_action,
            "last_action_by": a.last_action_by_role,
            "last_action_note": a.last_action_note,
        }
        for a in appointments
    ]


# ============================
# 🔹 Dentist Set Availability
# ============================
@router.post("/availability/manage")
def set_availability(request: Request, date: str = Form(...), available: bool = Form(...), db: Session = Depends(get_db)):

    dentist_email = request.session.get("email")
    if not dentist_email:
        return RedirectResponse(url="/", status_code=303)

    selected_date = datetime.strptime(date, "%Y-%m-%d").date()
    record = db.query(DentistAvailability).filter_by(dentist_email=dentist_email, date=selected_date).first()

    if record:
        record.is_available = available
    else:
        db.add(DentistAvailability(dentist_email=dentist_email, date=selected_date, is_available=available))

    db.commit()
    return {"success": True}


# ============================
# 🔹 CANCEL Appointment
# ============================
@router.post("/cancel")
def cancel_appointment(
    request: Request,
    appt_id: int = Form(...),
    db: Session = Depends(get_db)
):
    email = request.session.get("email")
    role = request.session.get("role", "resident")

    if not email:
        return RedirectResponse(url="/", status_code=303)

    appt = db.query(Appointment).filter(Appointment.id == appt_id).first()
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")

    appt.status = "cancelled"
    appt.updated_at = datetime.utcnow()

    timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
    appt.last_action_note = (
        f"Appointment cancelled due to clinic schedule adjustment on {timestamp}."
        if role == "dentist"
        else f"Appointment cancelled by patient on {timestamp}."
    )

    appt.last_action = "cancelled"
    appt.last_action_by_role = role

    db.commit()

    request.session["flash_message"] = "✅ Appointment cancelled successfully!"
    request.session["flash_type"] = "success"
    return RedirectResponse(url="/dashboard", status_code=303)


# ============================
# 🔹 RESCHEDULE Appointment
# ============================
@router.post("/reschedule")
def reschedule_appointment(
    request: Request,
    appt_id: int = Form(...),
    new_date: str = Form(...),
    new_time: str = Form(...),
    db: Session = Depends(get_db)
):
    email = request.session.get("email")
    role = request.session.get("role", "resident")

    if not email:
        return RedirectResponse(url="/", status_code=303)

    appt = db.query(Appointment).filter(Appointment.id == appt_id).first()
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")

    target_date = datetime.strptime(new_date, "%Y-%m-%d").date()
    if target_date < datetime.utcnow().date():
        request.session["flash_message"] = "⚠️ You cannot reschedule to a past date."
        request.session["flash_type"] = "error"
        return RedirectResponse(url=f"/appointment/details/{appt_id}", status_code=303)

    rest = (
        db.query(DentistAvailability)
        .filter(DentistAvailability.date == target_date,
                DentistAvailability.is_available == False)
        .first()
    )
    if rest:
        request.session["flash_message"] = "❌ The dentist is not available on that day."
        request.session["flash_type"] = "error"
        return RedirectResponse(url=f"/appointment/details/{appt_id}", status_code=303)

    SLOT_STARTS = ["08:00","09:00","10:00","11:00","13:00","14:00","15:00","16:00"]
    if new_time not in SLOT_STARTS:
        request.session["flash_message"] = "⚠️ Invalid time."
        request.session["flash_type"] = "warning"
        return RedirectResponse(url=f"/appointment/details/{appt_id}", status_code=303)

    new_dt = datetime.fromisoformat(f"{new_date}T{new_time}")

    clash = (
        db.query(Appointment)
        .filter(Appointment.date_time == new_dt,
                Appointment.status.notin_(["cancelled","rejected"]))
        .first()
    )
    if clash:
        request.session["flash_message"] = "⚠️ That time slot is already booked."
        request.session["flash_type"] = "warning"
        return RedirectResponse(url=f"/appointment/details/{appt_id}", status_code=303)

    if not appt.original_date:
        appt.original_date = appt.date_time

    appt.date_time = new_dt
    appt.status = "rescheduled"
    appt.updated_at = datetime.utcnow()

    ts = datetime.now().strftime("%B %d, %Y at %I:%M %p")
    appt.last_action_note = (
        f"Clinic adjustment due to schedule changes on {ts}."
        if role == "dentist"
        else f"Rescheduling requested by patient on {ts}."
    )
    appt.last_action = "rescheduled"
    appt.last_action_by_role = role

    db.commit()

    request.session["flash_message"] = "✅ Appointment rescheduled successfully!"
    request.session["flash_type"] = "success"
    return RedirectResponse(url="/dashboard", status_code=303)



# ============================
# 🔹 NEW: APPROVE Appointment (Dentist action)
# ============================
@router.post("/approve")
def approve_appointment(
    request: Request,
    appt_id: int = Form(...),
    db: Session = Depends(get_db)
):
    email = request.session.get("email")
    role = request.session.get("role")

    if not email or role != "dentist":
        raise HTTPException(status_code=403, detail="Unauthorized")

    appt = db.query(Appointment).filter(Appointment.id == appt_id).first()
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")

    appt.status = "accepted"
    appt.updated_at = datetime.utcnow()

    timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
    appt.last_action_note = f"Appointment approved by dentist on {timestamp}."
    appt.last_action = "accepted"
    appt.last_action_by_role = "dentist"

    db.commit()

    return {"success": True, "message": "Appointment approved successfully"}



# ============================
# 🔹 NEW: REJECT Appointment (Dentist action)
# ============================
@router.post("/reject")
def reject_appointment(
    request: Request,
    appt_id: int = Form(...),
    reason: str = Form("Your appointment request has been declined."),
    db: Session = Depends(get_db)
):
    email = request.session.get("email")
    role = request.session.get("role")

    if not email or role != "dentist":
        raise HTTPException(status_code=403, detail="Unauthorized")

    appt = db.query(Appointment).filter(Appointment.id == appt_id).first()
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")

    appt.status = "rejected"
    appt.updated_at = datetime.utcnow()

    timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
    appt.last_action_note = f"Rejected by dentist on {timestamp}. Reason: {reason}"
    appt.last_action = "rejected"
    appt.last_action_by_role = "dentist"

    db.commit()

    return {"success": True, "message": "Appointment rejected successfully"}



# ============================
# 🔹 Notifications
# ============================
@router.get("/notifications")
def get_notifications(request: Request, db: Session = Depends(get_db)):

    email = request.session.get("email")
    if not email:
        return {"count": 0, "notifications": []}

    notifications = (
        db.query(Appointment)
        .filter(
            Appointment.resident_email == email,
            Appointment.last_action_by_role == "dentist",
            Appointment.status.in_(["accepted", "rescheduled", "cancelled", "rejected"]),
            Appointment.seen_by_resident == False,
        )
        .order_by(desc(Appointment.updated_at))
        .limit(10)
        .all()
    )

    return {
        "count": len(notifications),
        "notifications": [
            {
                "id": a.id,
                "title": f"{a.title}",
                "message": a.last_action_note or f"{a.status.capitalize()} by dentist.",
                "status": a.status,
                "time": a.updated_at.strftime("%b %d, %Y %I:%M %p"),
            }
            for a in notifications
        ],
    }



@router.post("/notifications/mark-read")
def mark_notifications_as_read(request: Request, db: Session = Depends(get_db)):

    email = request.session.get("email")
    if not email:
        return {"success": False}

    db.query(Appointment).filter(
        Appointment.resident_email == email,
        Appointment.last_action_by_role == "dentist",
        Appointment.status.in_(["accepted", "rescheduled", "cancelled", "rejected"]),
        Appointment.seen_by_resident == False,
    ).update({Appointment.seen_by_resident: True})

    db.commit()
    return {"success": True}



# ============================
# 🔹 Details JSON
# ============================
@router.get("/details-json/{appt_id}")
def get_appointment_details_json(request: Request, appt_id: int, db: Session = Depends(get_db)):

    email = request.session.get("email")
    if not email:
        raise HTTPException(status_code=401, detail="Unauthorized")

    appt = db.query(Appointment).filter(Appointment.id == appt_id).first()
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")

    status = (appt.status or "").lower()
    show_both = appt.original_date is not None

    def fmt(dt):
        return dt.strftime("%B %d, %Y %I:%M %p") if dt else "N/A"

    if show_both:
        if status == "cancelled":
            main_label = "Cancelled Requested Date"
        elif "rescheduled" in status:
            main_label = "Requested New Date"
        else:
            main_label = "Requested Date"

        original_label = "Original Date"
        original_date = fmt(appt.original_date)
        main_date = fmt(appt.date_time)
    else:
        main_label = "Requested Date"
        original_label = ""
        original_date = ""
        main_date = fmt(appt.date_time)

    if status == "cancelled" and appt.original_date:
        status_text = "Cancelled Rescheduled"
    else:
        status_text = (appt.status or "N/A").capitalize()

    return {
        "id": appt.id,
        "service": appt.title or "N/A",
        "status_raw": appt.status or "N/A",
        "status_text": status_text,
        "note": appt.last_action_note or "",
        "show_both": show_both,
        "original_label": original_label,
        "main_label": main_label,
        "original_date": original_date,
        "main_date": main_date,
    }
@router.get("/details/{appt_id}", response_class=HTMLResponse)
def view_appointment_details(request: Request, appt_id: int, db: Session = Depends(get_db)):
    email = request.session.get("email")
    role = request.session.get("role", "resident")
    if not email:
        return RedirectResponse(url="/", status_code=303)

    appt = db.query(Appointment).filter(Appointment.id == appt_id).first()
    if not appt:
        return HTMLResponse("<h3>Appointment not found or access denied.</h3>", status_code=404)

    # ⭐ Prevent crash if fields are null
    status = (appt.status or "").lower()
    last_action_note = appt.last_action_note or ""
    last_action_by = appt.last_action_by_role or ""

    # ⭐ Prevent crash on NoneType date_time
    if appt.date_time:
        date_time_display = appt.date_time.strftime("%B %d, %Y %I:%M %p")
    else:
        date_time_display = "No date set"

    if appt.updated_at:
        dentist_note_time = appt.updated_at.strftime("%B %d, %Y %I:%M %p")
    else:
        dentist_note_time = None

    # Status logic
    if role in ["admin", "dentist"]:
        can_reschedule = status in ["pending", "approved", "rescheduled"]
        can_cancel = status in ["pending", "approved", "rescheduled"]
    else:
        can_reschedule = status == "pending"
        can_cancel = status in ["pending", "rescheduled"]

    return templates.TemplateResponse(
        "appointment_details.html",
        {
            "request": request,
            "appointment": appt,
            "date_time_display": date_time_display,
            "can_cancel": can_cancel,
            "can_reschedule": can_reschedule,
            "dentist_note": last_action_note,
            "dentist_note_time": dentist_note_time,
            "last_action_by_role": last_action_by
        }
    )
