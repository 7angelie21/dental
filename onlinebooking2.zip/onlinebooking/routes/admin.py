from fastapi import APIRouter, Request, Depends, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from collections import defaultdict
from datetime import datetime

from config.database import SessionLocal
from models.user import User
from models.appointment import Appointment
from typing import Optional
from pydantic import BaseModel

router = APIRouter(prefix="/admin", tags=["Admin"])
templates = Jinja2Templates(directory="templates")


# ------------------ Database Dependency ------------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ------------------ Helper: Check if Admin Logged In ------------------
def get_current_admin(request: Request, db: Session):
    email = request.session.get("email")
    if not email:
        return None
    return db.query(User).filter(User.email == email, User.role == "admin").first()

# ------------------ Reschedule Payload ------------------
class ReschedulePayload(BaseModel):
    newDate: Optional[str] = None  # format: YYYY-MM-DD
    newTime: Optional[str] = None  # format: HH:MM


# ------------------ Admin Dashboard ------------------
@router.get("/dashboard", response_class=HTMLResponse)
def admin_dashboard(request: Request, db: Session = Depends(get_db)):
    user = get_current_admin(request, db)
    if not user:
        return RedirectResponse(url="/", status_code=302)

    appointments = db.query(Appointment).all()
    MAX_SLOTS_PER_DAY = 6
    slots_per_day = defaultdict(int)

    # Count slots per day
    for appt in appointments:
        if appt.date_time:
            day_str = appt.date_time.strftime("%Y-%m-%d")
            slots_per_day[day_str] += 1

    events = []
    availability = []  # define it to prevent errors
    unavailability = []  # Currently empty; you can fill this from your DB later


    for appt in appointments:
        if appt.date_time:
            events.append({
                "title": f"{appt.title} ({appt.status})",
                "start": appt.date_time.isoformat(),
                "color": "red" if appt.status == "pending" else "green",
                "resident_name": getattr(appt, "resident_name", "Unknown"),
                "blocked": True
            })

    # Generate availability info
    for day, count in slots_per_day.items():
        if count >= MAX_SLOTS_PER_DAY:
            availability.append({
                "date": day,
                "title": "Fully Booked",
                "display": "background",
                "color": "#cccccc"
            })
        else:
            availability.append({
                "date": day,
                "title": f"{MAX_SLOTS_PER_DAY - count} slots available",
                "display": "background",
                "color": "#a8d5a2"
            })

    return templates.TemplateResponse("admin_dashboard.html", {
        "request": request,
        "user": user,
        "appointments": events,
        "availability": availability,
        "unavailability": unavailability
    })


# ------------------ Admin - View All Residents ------------------
@router.get("/residents", response_class=HTMLResponse)
def list_residents(request: Request, db: Session = Depends(get_db)):
    user = get_current_admin(request, db)
    if not user:
        return RedirectResponse(url="/")

    residents = db.query(User).filter(User.role == "resident").all()

    return templates.TemplateResponse("admin_residents.html", {
        "request": request,
        "user": user,
        "residents": residents
    })


# ------------------ Admin - View Single Resident Profile ------------------
@router.get("/residents/{resident_id}", response_class=HTMLResponse)
def resident_profile(request: Request, resident_id: int, db: Session = Depends(get_db)):
    user = get_current_admin(request, db)
    if not user:
        return RedirectResponse(url="/")

    resident = db.query(User).filter(
        User.id == resident_id,
        User.role == "resident"
    ).first()

    if not resident:
        return templates.TemplateResponse("error.html", {
            "request": request,
            "message": "⚠️ Resident not found."
        }, status_code=404)

    appointments = db.query(Appointment).filter(Appointment.resident_email == resident.email).all()

    formatted_appointments = [
        {
            "date_time": appt.date_time.strftime("%Y-%m-%d %I:%M %p") if appt.date_time else "",
            "service": appt.title,
            "status": appt.status
        }
        for appt in appointments
    ]

    return templates.TemplateResponse("resident_profile.html", {
        "request": request,
        "user": user,
        "resident": resident,
        "appointments": formatted_appointments
    })


# ------------------ Admin - Pending Requests ------------------
@router.get("/requests", response_class=HTMLResponse)
def admin_requests(request: Request, db: Session = Depends(get_db)):
    user = get_current_admin(request, db)
    if not user:
        return RedirectResponse(url="/")

    # Fetch pending, approved, and rescheduled appointments
    requests_data = db.query(Appointment).filter(
        Appointment.status.in_(["pending", "approved", "rescheduled"])
    ).all()

    return templates.TemplateResponse("admin_requests.html", {
        "request": request,
        "user": user,
        "requests": requests_data
    })

# ------------------ Admin - Status Update Endpoints ------------------
@router.post("/request/{appointment_id}/approve")
def approve_appointment(appointment_id: int, db: Session = Depends(get_db)):
    appointment = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")

    appointment.status = "approved"
    appointment.updated_at = datetime.utcnow()
    db.commit()
    return JSONResponse({"message": "Appointment approved", "status": "approved"})


@router.post("/request/{appointment_id}/reject")
def reject_appointment(appointment_id: int, db: Session = Depends(get_db)):
    appointment = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")

    appointment.status = "rejected"
    appointment.updated_at = datetime.utcnow()
    db.commit()
    return JSONResponse({"message": "Appointment rejected", "status": "rejected"})

# ------------------ Admin - Reschedule Appointment ------------------
@router.post("/request/{appointment_id}/reschedule")
def reschedule_appointment(
    appointment_id: int,
    payload: ReschedulePayload,
    db: Session = Depends(get_db)
):
    appointment = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")

    # Keep original date and time if not provided
    old_dt = appointment.date_time
    date_str = payload.newDate if payload.newDate else old_dt.strftime("%Y-%m-%d")
    time_str = payload.newTime if payload.newTime else old_dt.strftime("%H:%M")

    # Combine into new datetime
    new_datetime = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")

    appointment.date_time = new_datetime
    appointment.status = "rescheduled"
    appointment.updated_at = datetime.utcnow()
    db.commit()

    return JSONResponse({
        "message": f"Rescheduled to {date_str} {time_str}",
        "status": "rescheduled",
        "newDateTime": new_datetime.strftime("%Y-%m-%d %H:%M")
    })

@router.post("/request/{appointment_id}/finish")
def finish_appointment(appointment_id: int, db: Session = Depends(get_db)):
    appointment = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")

    appointment.status = "completed"
    appointment.updated_at = datetime.utcnow()
    db.commit()
    return JSONResponse({"message": "Appointment marked as completed and moved to history", "status": "completed"})


# ------------------ Admin - Appointment History ------------------
@router.get("/history", response_class=HTMLResponse)
def admin_history(request: Request, db: Session = Depends(get_db)):
    user = get_current_admin(request, db)
    if not user:
        return RedirectResponse(url="/", status_code=302)

    # Fetch all appointments with these statuses, no date limit
    history_data = db.query(Appointment).filter(
        Appointment.status.in_(["completed", "rejected", "rescheduled", "approved", "cancelled"])
    ).order_by(Appointment.date_time.desc()).all()  # latest first

    return templates.TemplateResponse("admin_history.html", {
        "request": request,
        "user": user,
        "history": history_data
    })



# ------------------ Admin - Walk-In Page ------------------
@router.get("/walk-in", response_class=HTMLResponse)
def admin_walk_in(request: Request, db: Session = Depends(get_db)):
    """
    Admin Walk-In page: only accessible to admins.
    """
    user = get_current_admin(request, db)
    if not user:
        return RedirectResponse(url="/", status_code=302)
    
    # You can fetch residents if needed for walk-ins
    residents = db.query(User).filter(User.role == "resident").all()

    return templates.TemplateResponse("walk-in.html", {
        "request": request,
        "user": user,
        "residents": residents
    })

# ------------------ Admin - Walk-In Add ------------------
@router.post("/walk-in/add")
def add_walk_in(
    request: Request,
    resident_id: int = Form(...),
    service: str = Form(...),
    date_time: str = Form(...),  # <-- hidden input
    db: Session = Depends(get_db)
):
    resident = db.query(User).filter(User.id == resident_id, User.role == "resident").first()
    if not resident:
        return templates.TemplateResponse("walk-in.html", {
            "request": request,
            "user": get_current_admin(request, db),
            "residents": db.query(User).filter(User.role == "resident").all(),
            "message": "⚠️ Resident not found.",
            "message_type": "error"
        })

    try:
        # parse the hidden field directly
        date_time_obj = datetime.strptime(date_time, "%m/%d/%Y %I:%M %p")
    except ValueError:
        return templates.TemplateResponse("walk-in.html", {
            "request": request,
            "user": get_current_admin(request, db),
            "residents": db.query(User).filter(User.role == "resident").all(),
            "message": "⚠️ Invalid date or time format.",
            "message_type": "error"
        })

    new_appointment = Appointment(
        user_id=resident.id,
        resident_email=resident.email,
        resident_name=resident.name,
        title=service,
        date_time=date_time_obj,
        status="pending",
        created_at=datetime.utcnow()
    )
    db.add(new_appointment)
    db.commit()

    return templates.TemplateResponse("walk-in.html", {
        "request": request,
        "user": get_current_admin(request, db),
        "residents": db.query(User).filter(User.role == "resident").all(),
        "message": "✅ Walk-in appointment added successfully!",
        "message_type": "success"
    })