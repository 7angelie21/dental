# routers/notifications.py
from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from datetime import datetime
from models.user import User
from models.appointment import Appointment
from config.database import SessionLocal
from models.notifications import ClinicNotification

router = APIRouter()

# Dependency for DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# -----------------------------
# GET ALL NOTIFICATIONS
# -----------------------------
@router.get("/clinic_notifications")
async def get_notifications(request: Request, db: Session = Depends(get_db)):
    email = request.session.get("email")
    if not email:
        return JSONResponse({"count": 0, "notifications": []})

    user = db.query(User).filter(User.email == email).first()
    if not user:
        return JSONResponse({"count": 0, "notifications": []})

    if user.role == "admin":
        # Admin sees all notifications
        notifications = db.query(ClinicNotification)\
            .order_by(ClinicNotification.created_at.desc())\
            .limit(50).all()
    else:
        # Residents see only their own appointment notifications with specific statuses
        notifications = db.query(ClinicNotification)\
            .join(Appointment, ClinicNotification.appointment_id == Appointment.id)\
            .filter(ClinicNotification.user_id == user.id)\
            .filter(Appointment.status.in_(["accepted","rejected","completed","reschedule"]))\
            .order_by(ClinicNotification.created_at.desc())\
            .limit(50).all()

    result = []
    for n in notifications:
        # Build message
        if n.type == "new_resident" and user.role == "admin":
            msg = f"New resident registered: {n.user.name}"
        elif n.type == "booking":
            msg = f"{n.user.name} booked {n.appointment.title} on {n.appointment.date_time}"
        elif n.type == "cancellation":
            msg = f"{n.user.name} cancelled appointment on {n.appointment.date_time}"
        elif n.type == "reschedule":
            msg = f"{n.user.name} rescheduled {n.appointment.title} to {n.appointment.date_time}"
        else:
            msg = "Notification"

        result.append({
            "id": n.id,
            "type": n.type,
            "message": msg,
            "picture": n.user.picture or "/static/default.png",
            "name": n.user.name,
            "created_at": n.created_at.isoformat(),
            "is_read": n.is_read
        })

    return JSONResponse({"count": len(result), "notifications": result})

# -----------------------------
# MARK NOTIFICATIONS AS READ
# -----------------------------
@router.post("/clinic_notifications/mark-read")
async def mark_notifications_read(request: Request, db: Session = Depends(get_db)):
    email = request.session.get("email")
    if not email:
        return JSONResponse({"success": False})

    user = db.query(User).filter(User.email == email).first()
    if not user:
        return JSONResponse({"success": False})

    if user.role == "admin":
        # Admin marks all notifications as read
        notifications = db.query(ClinicNotification).all()
    else:
        notifications = db.query(ClinicNotification)\
            .join(Appointment, ClinicNotification.appointment_id == Appointment.id)\
            .filter(ClinicNotification.user_id == user.id)\
            .filter(Appointment.status.in_(["accepted","rejected","completed","reschedule"]))\
            .all()

    for n in notifications:
        n.is_read = True
    db.commit()

    return JSONResponse({"success": True})
