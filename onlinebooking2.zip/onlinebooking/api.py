from flask import Blueprint, jsonify, request
from uuid import uuid4

slots_api = Blueprint('slots_api', __name__)

# In-memory storage for slots
slots = []

@slots_api.route('/api/slots', methods=['GET', 'POST'])
def manage_slots():
    if request.method == 'GET':
        # Return events for FullCalendar
        return jsonify([
            {
                "id": slot["id"],
                "title": slot["booked"] and f'Booked by {slot["resident"]}' or "Available",
                "start": slot["start"],
                "end": slot["end"],
                "booked": slot["booked"],
                "color": slot["booked"] and 'red' or 'green'
            } for slot in slots
        ])
    else:
        data = request.get_json()
        slot = {
            "id": str(uuid4()),
            "start": data["start"],
            "end": data["end"],
            "booked": False,
            "resident": None
        }
        slots.append(slot)
        return jsonify(slot)

@slots_api.route('/api/book/<slot_id>', methods=['POST'])
def book_slot(slot_id):
    data = request.get_json()
    for slot in slots:
        if slot["id"] == slot_id:
            if slot["booked"]:
                return jsonify({"error": "Already booked"}), 400
            slot["booked"] = True
            slot["resident"] = data["resident"]
            return jsonify(slot)
    return jsonify({"error": "Slot not found"}), 404
