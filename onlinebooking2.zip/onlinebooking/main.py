from fastapi import FastAPI, Request, Depends
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Enum
from sqlalchemy.orm import relationship
from datetime import datetime
import os

# Local imports
from config.database import Base, engine, SessionLocal
from auth import router as auth_router
from routes import appointment, dashboard, history, admin
from models.user import User
from models.appointment import Appointment
from routes import dentist_unavailability
from models.notifications import ClinicNotification


# ==========================================================
# 🧩 APP INITIALIZATION
# ==========================================================
app = FastAPI(title="Dental Clinic")

app.add_middleware(SessionMiddleware, secret_key="supersecretkey123")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

templates = Jinja2Templates(directory="templates")

# ==========================================================
# 🗄 DATABASE DEPENDENCY
# ==========================================================
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ==========================================================
# 🚦 ROUTERS
# ==========================================================
app.include_router(auth_router)
app.include_router(appointment.router)
app.include_router(dashboard.router)
app.include_router(admin.router)
app.include_router(history.router)
app.include_router(dentist_unavailability.router)

# ==========================================================
# 🏠 LOGIN & LOGOUT
# ==========================================================
@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse(url="/")

# ==========================================================
# 🧑‍⚕️ ADMIN DASHBOARD
# ==========================================================
@app.get("/admin/dashboard", response_class=HTMLResponse)
def admin_dashboard(request: Request, db: Session = Depends(get_db)):
    email = request.session.get("email")
    if not email:
        return RedirectResponse(url="/")

    user = db.query(User).filter(User.email == email).first()
    if not user or user.role != "admin":
        return RedirectResponse(url="/dashboard/")

    appointments = db.query(Appointment).all()
    residents = db.query(User).filter(User.role == "resident").all()

    return templates.TemplateResponse(
        "admin_dashboard.html",
        {
            "request": request,
            "user": user,
            "appointments": appointments,
            "residents": residents
        }
    )

# ==========================================================
# 👩‍💻 RESIDENT DASHBOARD
# ==========================================================
@app.get("/dashboard/", response_class=HTMLResponse)
def resident_dashboard(request: Request, db: Session = Depends(get_db)):
    email = request.session.get("email")
    if not email:
        return RedirectResponse(url="/")

    user = db.query(User).filter(User.email == email).first()
    if not user:
        return HTMLResponse("⚠ User not found", status_code=404)

    if user.role == "admin":
        return RedirectResponse(url="/admin/dashboard")

    appointments = db.query(Appointment).filter(Appointment.resident_email == user.email).all()

    appointments_data = [
        {
            "title": appt.title,
            "date_time": appt.date_time.isoformat(),
            "color": "green",
        }
        for appt in appointments if appt.date_time
    ]

    return templates.TemplateResponse(
        "resident_dashboard.html",
        {
            "request": request,
            "user": user,
            "appointments": appointments_data,
        }
    )
# ==========================================================
# 🔔 CLINIC NOTIFICATIONS ENDPOINT (Fixed)
# ==========================================================
from sqlalchemy import or_

@app.get("/clinic_notifications")
def clinic_notifications(request: Request, db: Session = Depends(get_db)):
    email = request.session.get("email")
    if not email:
        return JSONResponse({"count": 0, "notifications": []})

    user = db.query(User).filter(User.email == email).first()
    if not user:
        return JSONResponse({"count": 0, "notifications": []})

    if user.role == "admin":
        # Admin sees all notifications
        notifications = db.query(ClinicNotification)\
            .order_by(ClinicNotification.created_at.desc())\
            .limit(50).all()
    else:
        # Residents see only their own notifications
        # Use outerjoin and primaryjoin to avoid NoForeignKeysError
        notifications = db.query(ClinicNotification)\
            .outerjoin(
                Appointment,
                ClinicNotification.appointment_id == Appointment.id
            )\
            .filter(ClinicNotification.user_id == user.id)\
            .filter(
                or_(
                    Appointment.status.in_(["accepted", "rejected", "completed", "reschedule"]),
                    ClinicNotification.appointment_id == None
                )
            )\
            .order_by(ClinicNotification.created_at.desc())\
            .limit(50).all()

    result = []
    for n in notifications:
        # Build the notification message
        if n.type == "new_resident" and user.role == "admin":
            msg = f"New resident registered: {n.user.name}"
        elif n.type == "booking":
            if n.appointment:
                msg = f"{n.user.name} booked {n.appointment.title} on {n.appointment.date_time}"
            else:
                msg = f"{n.user.name} made a booking"
        elif n.type == "cancellation":
            if n.appointment:
                msg = f"{n.user.name} cancelled appointment on {n.appointment.date_time}"
            else:
                msg = f"{n.user.name} cancelled a booking"
        elif n.type == "reschedule":
            if n.appointment:
                msg = f"{n.user.name} rescheduled {n.appointment.title} to {n.appointment.date_time}"
            else:
                msg = f"{n.user.name} rescheduled a booking"
        else:
            msg = "Notification"

        result.append({
            "id": n.id,
            "type": n.type,
            "message": msg,
            "picture": n.user.picture or "/static/default.png",
            "name": n.user.name,
            "created_at": n.created_at.isoformat(),
            "is_read": n.is_read
        })

    return JSONResponse({"count": len(result), "notifications": result})
