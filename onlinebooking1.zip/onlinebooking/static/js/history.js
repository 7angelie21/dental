document.addEventListener("DOMContentLoaded", () => {
  const filter = document.getElementById("statusFilter");
  const list = document.getElementById("historyList");
  const items = list ? Array.from(list.querySelectorAll(".history-item")) : [];
  const prevBtn = document.getElementById("prevPage");
  const nextBtn = document.getElementById("nextPage");
  const pageIndicator = document.getElementById("pageIndicator");

  const ITEMS_PER_PAGE = 5;
  let currentPage = 1;
  let filteredItems = items;

  function renderPage() {
    if (!list) return;
    list.innerHTML = "";
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE;
    const visible = filteredItems.slice(start, end);

    if (visible.length === 0) {
      list.innerHTML = `<p class="empty">No appointments found.</p>`;
      pageIndicator.textContent = "";
    } else {
      visible.forEach(li => list.appendChild(li));
      pageIndicator.textContent = `Page ${currentPage} of ${Math.ceil(filteredItems.length / ITEMS_PER_PAGE)}`;
    }
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === Math.ceil(filteredItems.length / ITEMS_PER_PAGE);
  }

  filter.addEventListener("change", () => {
    const value = filter.value.toLowerCase();
    filteredItems = items.filter(item => {
      const status = (item.dataset.status || "").toLowerCase();
      return value === "all" || status === value;
    });
    currentPage = 1;
    renderPage();
  });

  prevBtn.addEventListener("click", () => {
    if (currentPage > 1) { currentPage--; renderPage(); }
  });
  nextBtn.addEventListener("click", () => {
    if (currentPage < Math.ceil(filteredItems.length / ITEMS_PER_PAGE)) { currentPage++; renderPage(); }
  });

  renderPage();

  // ===== Modal wiring =====
  const modal = document.getElementById("appointmentModal");
  const pOriginal = document.getElementById("pOriginal");
  const pMain = document.getElementById("pMain");
  const lblOriginal = document.getElementById("lblOriginal");
  const lblMain = document.getElementById("lblMain");

  list.addEventListener("click", async (e) => {
    const li = e.target.closest(".history-item");
    if (!li) return;

    const id = li.dataset.id;
    if (!id) return;

    try {
      const res = await fetch(`/appointment/details-json/${id}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();

      // Service
      document.getElementById("modalService").textContent = data.service || "N/A";

      // Dates with labels to match appointment_details.html
      if (data.show_both) {
        pOriginal.style.display = "block";
        lblOriginal.textContent = (data.original_label || "Original Date") + ":";
        document.getElementById("modalOriginal").textContent = data.original_date || "N/A";

        pMain.style.display = "block";
        lblMain.textContent = (data.main_label || "Requested New Date") + ":";
        document.getElementById("modalMain").textContent = data.main_date || "N/A";
      } else {
        pOriginal.style.display = "none";
        pMain.style.display = "block";
        lblMain.textContent = (data.main_label || "Requested Date") + ":";
        document.getElementById("modalMain").textContent = data.main_date || "N/A";
      }

      // Status badge text and class
      const statusEl = document.getElementById("modalStatus");
      statusEl.textContent = data.status_text || data.status_raw || "N/A";
      statusEl.className = "status-badge " + (data.status_raw || "").toLowerCase().replace(/\s+/g, "-");

      // Note
      const noteBox = document.getElementById("modalNoteBox");
      const notesEl = document.getElementById("modalNotes");
      if (data.note) {
        noteBox.hidden = false;
        notesEl.textContent = data.note;
      } else {
        noteBox.hidden = true;
        notesEl.textContent = "";
      }

      modal.style.display = "flex";
    } catch (err) {
      console.error("Failed to load details:", err);
    }
  });

  // Close UX (X, backdrop, ESC)
  document.addEventListener("click", (e) => {
    if (e.target.closest(".close-btn")) modal.style.display = "none";
  });
  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.style.display = "none";
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") modal.style.display = "none";
  });
});
