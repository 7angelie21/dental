// ================= SIDEBAR TOGGLE =================
document.getElementById("menuToggle").addEventListener("click", () => {
  document.getElementById("sidebar").classList.toggle("active");
});

// ================= FULLCALENDAR =================
document.addEventListener("DOMContentLoaded", function () {
  const calendarEl = document.getElementById("calendar");
  const appointmentsEl = document.getElementById("appointments-data");
  const unavailabilityEl = document.getElementById("unavailability-data");
  if (!calendarEl || !appointmentsEl) return;

  const appointments = JSON.parse(appointmentsEl.textContent);
  const unavailabilityData = JSON.parse(unavailabilityEl.textContent);

  const SLOT_STARTS = ["08:00","09:00","10:00","11:00","13:00","14:00","15:00","16:00"];
  const MAX_SLOTS = SLOT_STARTS.length;

  const now = new Date();
  const todayStr = now.toISOString().split("T")[0];

  const upcomingAppointments = appointments.filter(appt => new Date(appt.start) >= now);

  // Helper: format time to 12-hour am/pm
  function formatTime(time) {
    const [hour, minute] = time.split(":");
    let hr = parseInt(hour);
    const suffix = hr >= 12 ? "pm" : "am";
    hr = hr % 12 || 12;
    return `${hr}${suffix}`;
  }

 // Count bookings per day (excluding rejected/cancelled)
const slotsPerDay = {};
upcomingAppointments.forEach(appt => {
  if (appt.status === "rejected" || appt.status === "cancelled") return; // ignore these
  const day = appt.start.split("T")[0];
  slotsPerDay[day] = (slotsPerDay[day] || 0) + 1;
});


  // Generate availability events for current month
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

  const availabilityEvents = [];
  for (let i = 0; i < endOfMonth.getDate(); i++) {
    const d = new Date(now.getFullYear(), now.getMonth(), i + 1);
    const dayStr = d.toLocaleDateString('en-CA');
    if (dayStr < todayStr) continue; // skip past days

    const booked = slotsPerDay[dayStr] || 0;
    let slotsAvailable = MAX_SLOTS - booked;

    // Subtract past slots for today
    if (dayStr === todayStr) {
      SLOT_STARTS.forEach(slot => {
        const slotTime = new Date(`${dayStr}T${slot}`);
        if (slotTime <= now) slotsAvailable--;
      });
    }

    slotsAvailable = Math.max(slotsAvailable, 0);

    availabilityEvents.push({
      start: dayStr,
      allDay: true,
      display: "background",
      title: slotsAvailable === 0 ? "No slots available" : `${slotsAvailable} slots available`,
      color: slotsAvailable === 0 ? "#e74c3c" : "#ffffff",
      extendedProps: { slotsAvailable },
       borderColor: "#ccc"
    });
  }

  // Unavailability events
  const unavailableEvents = unavailabilityData.map(u => {
    const start = u.start_time ? `${u.start_date}T${u.start_time}` : u.start_date;
    let end;
    if(u.end_date){
      end = u.end_date;
      if(u.start_time && u.end_time) end = `${u.end_date}T${u.end_time}`;
    } else if(u.end_time){
      end = `${u.start_date}T${u.end_time}`;
    }
    return { start, end, display:"background", title:"Unavailable", color:"#ffcccc", classNames:["unavailable"] };
  });

  // Appointment dots
  const appointmentEvents = upcomingAppointments.map(appt => ({
    title: "●",
    start: appt.start,
    color: appt.status === "pending" ? "#f39c12" :
           appt.status === "accepted" ? "#27ae60" :
           appt.status === "rejected" ? "#c0392b" :
           appt.status === "reschedule" ? "#2980b9" : "#7f8c8d",
    extendedProps: { 
      resident: appt.resident_name, 
      service: appt.title, 
      time: formatTime(appt.start.split("T")[1].substring(0,5))
    },
    allDay: false
  }));

  // Initialize FullCalendar
  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: "dayGridMonth",
    headerToolbar: { 
      left: "prev,next today", 
      center: "title", 
      right: "dayGridMonth,timeGridWeek,timeGridDay" 
    },
    fixedWeekCount: false,
    showNonCurrentDates: true,
    height: "auto",
    contentHeight: "auto",
    expandRows: true,

    events: [
      ...availabilityEvents,
      ...appointmentEvents,
      ...unavailableEvents
    ],

    // Custom rendering for appointment dots and availability
   eventContent: function(arg) {
  if (arg.event.extendedProps.time) {
    // appointment dot with time
    return { 
      html: `<div style="text-align:center;">
               <div style="font-size:17px; line-height:12px;">●</div>
               <div style="font-size:10px; margin-top:2px;">${arg.event.extendedProps.time}</div>
             </div>` 
    };
  } 
  else if (arg.event.extendedProps.slotsAvailable !== undefined) {
  const text = arg.event.extendedProps.slotsAvailable === 0 ? "No slots available" : `${arg.event.extendedProps.slotsAvailable} slots`;
  const color = "#000";

  return { 
    html: `
      <div style="
        position:absolute;
        top:50%;
        left:50%;
        transform:translate(-50%, -50%);
        font-size:10px;
        text-align:center;
        pointer-events:none;
        color:${color};
        width: 100%;
      ">
        ${text}
      </div>
    ` 
  };
}

},

    eventClick: function(info) {
      if (info.event.extendedProps.resident) {
        const bookingList = document.getElementById("bookingList");
        const selectedDate = document.getElementById("selectedDate");
        selectedDate.textContent = info.event.startStr.split("T")[0];

        const sameDayAppointments = upcomingAppointments.filter(
          a => a.start.split("T")[0] === info.event.startStr.split("T")[0]
        );

        bookingList.innerHTML = sameDayAppointments.map(a => `
          <div class="booking-item">
            <p><strong>Patient:</strong> ${a.resident_name}</p>
            <p><strong>Service:</strong> ${a.title}</p>
            <p><strong>Time:</strong> ${formatTime(a.start.split("T")[1].substring(0,5))}</p>
          </div>
        `).join('');
      }
    },

    dayMaxEvents: 2, // Limit to 2 dots per day
    dayMaxEventRows: false, // keep +N indicator visible
    selectable: false
  });

  calendar.render();

  // ====== RESIZE FIX FOR MOBILE ======
  window.addEventListener("resize", () => calendar.updateSize());
});
