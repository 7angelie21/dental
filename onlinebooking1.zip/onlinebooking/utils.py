from fastapi import Request
from sqlalchemy.orm import Session
from models.user import User

def get_current_user(request: Request, db: Session) -> User | None:
    """Fetch the logged-in user from session."""
    email = request.session.get("email")
    if not email:
        return None
    return db.query(User).filter(User.email == email).first()
