from fastapi import FastAPI, Request, Depends
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, RedirectResponse
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy.orm import Session

# Local imports
from config.database import Base, engine, SessionLocal
from auth import router as auth_router
from routes import appointment, dashboard, history, admin
from models.user import User
from models.appointment import Appointment
from routes import dentist_unavailability
import os

# ==========================================================
# 🧩 APP INITIALIZATION
# ==========================================================
app = FastAPI(title="Dental Clinic")

# ✅ Enable session middleware
app.add_middleware(SessionMiddleware, secret_key="supersecretkey123")

# ✅ Mount static files (so /static/... works)
#    This ensures {{ url_for('static', filename='css/style.css') }} works.
# ✅ Get the absolute path to the 'static' folder
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")

# ✅ Mount static files properly
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
# ✅ Jinja2 Templates folder
templates = Jinja2Templates(directory="templates")

# ✅ Auto-create all database tables
Base.metadata.create_all(bind=engine)

# ==========================================================
# 🗄 DATABASE DEPENDENCY
# ==========================================================
def get_db():
    """Provide a transactional database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ==========================================================
# 🚦 ROUTERS (organize feature routes)
# ==========================================================
app.include_router(auth_router)
app.include_router(appointment.router)
app.include_router(dashboard.router)
app.include_router(admin.router)
app.include_router(history.router)
app.include_router(dentist_unavailability.router)


# ==========================================================
# 🏠 LOGIN PAGE
# ==========================================================
@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

# ==========================================================
# 🚪 LOGOUT ROUTE
# ==========================================================
@app.get("/logout")
def logout(request: Request):
    """Clear user session and redirect to login."""
    request.session.clear()
    return RedirectResponse(url="/")

# ==========================================================
# 🧑‍⚕️ ADMIN DASHBOARD
# ==========================================================
@app.get("/admin/dashboard", response_class=HTMLResponse)
def admin_dashboard(request: Request, db: Session = Depends(get_db)):
    """Admin dashboard — view all residents and appointments."""
    email = request.session.get("email")
    if not email:
        return RedirectResponse(url="/")

    user = db.query(User).filter(User.email == email).first()
    if not user or user.role != "admin":
        return RedirectResponse(url="/dashboard/")  # redirect non-admins

    # Admin sees all appointments and residents
    appointments = db.query(Appointment).all()
    residents = db.query(User).filter(User.role == "resident").all()

    return templates.TemplateResponse(
        "admin_dashboard.html",
        {
            "request": request,
            "user": user,
            "appointments": appointments,
            "residents": residents
        }
    )

# ==========================================================
# 👩‍💻 RESIDENT DASHBOARD
# ==========================================================
@app.get("/dashboard/", response_class=HTMLResponse)
def resident_dashboard(request: Request, db: Session = Depends(get_db)):
    """Resident dashboard — view only their appointments."""
    email = request.session.get("email")
    if not email:
        return RedirectResponse(url="/")

    user = db.query(User).filter(User.email == email).first()
    if not user:
        return HTMLResponse("⚠ User not found", status_code=404)

    # Only residents can access this dashboard
    if user.role == "admin":
        return RedirectResponse(url="/admin/dashboard")

    # Resident sees only their appointments
    appointments = db.query(Appointment).filter(
        Appointment.resident_email == user.email
    ).all()

    # Format appointments for FullCalendar
    appointments_data = [
        {
            "title": appt.title,
            "date_time": appt.date_time.isoformat(),
            "color": "green",
        }
        for appt in appointments if appt.date_time
    ]

    return templates.TemplateResponse(
        "resident_dashboard.html",
        {
            "request": request,
            "user": user,
            "appointments": appointments_data,
        }
    )

