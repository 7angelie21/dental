from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from authlib.integrations.starlette_client import OAuth
from config.database import SessionLocal
from models.user import User
import os
from dotenv import load_dotenv

load_dotenv(".env")

GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET")
GOOGLE_REDIRECT_URI = os.getenv("GOOGLE_REDIRECT_URI")

router = APIRouter(prefix="/auth", tags=["Authentication"])

oauth = OAuth()
oauth.register(
    name="google",
    client_id=GOOGLE_CLIENT_ID,
    client_secret=GOOGLE_CLIENT_SECRET,
    server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
    client_kwargs={"scope": "openid email profile"},
)

# ---------------- Login via Google ----------------
@router.get("/login")
async def login_via_google(request: Request):
    return await oauth.google.authorize_redirect(request, GOOGLE_REDIRECT_URI)

# ---------------- Callback ----------------
@router.get("/callback")
async def auth_callback(request: Request):
    token = await oauth.google.authorize_access_token(request)
    user_info = token.get("userinfo")

    if not user_info:
        return HTMLResponse("Failed to get user info", status_code=400)

    db = SessionLocal()
    user = db.query(User).filter(User.email == user_info["email"]).first()

    if not user:
        new_user = User(
            email=user_info["email"],
            name=user_info["name"],
            role="resident",  # Default role
            picture=user_info.get("picture")
        )
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        user = new_user
    else:
        user.picture = user_info.get("picture")
        db.commit()

    # ✅ Store email in session instead of query param
    request.session["email"] = user.email

    db.close()
     # 🔹 Redirect based on role
    if user.role == "admin":
        return RedirectResponse(url="/admin/dashboard")
    else:
        return RedirectResponse(url="/dashboard")  # resident view

@router.get("/existing-account", response_class=HTMLResponse)
async def existing_account_form():
    return """
    <html>
    <head>
        <title>Login to Existing Account</title>
        <link rel="stylesheet" href="/static/css/style.css">
    </head>
    <body>
        <div class="container">
            <img src="/static/img/dental logo.png" alt="Dental Clinic" class="logo">
            <h2>Login to Existing Account</h2>
            <p>Enter your email and password to login.</p>
            <form action="/auth/existing-account" method="post">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" class="existing-btn">Login</button>
            </form>
        </div>
    </body>
    </html>
    """
