from .user import User
from .appointment import Appointment  # if you added it
