from sqlalchemy import Column, Integer, String
from config.database import Base

class User(Base):
    __tablename__ = "clinic_user"  # table name stays as "user"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, nullable=False)
    name = Column(String, nullable=False)
    role = Column(String, default="resident")
    picture = Column(String, nullable=True)  # 👈 added profile picture column
