from sqlalchemy import Column, Integer, String, Date, Boolean, ForeignKey
from config.database import Base

class DentistAvailability(Base):
    __tablename__ = "dentist_availability"
    id = Column(Integer, primary_key=True, index=True)
    dentist_email = Column(String, ForeignKey("clinic_user.email"), nullable=False)
    date = Column(Date, nullable=False)
    is_available = Column(Boolean, default=True)
