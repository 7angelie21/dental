# models/unavailability.py
from sqlalchemy import Column, Integer, Date, Time, DateTime, ForeignKey, func
from config.database import Base

class DentistUnavailability(Base):
    __tablename__ = "dentist_unavailability"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("clinic_user.id"), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date)
    start_time = Column(Time)
    end_time = Column(Time)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
