from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, func, Boolean
from config.database import Base

class Appointment(Base):
    __tablename__ = "appointment"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("clinic_user.id"))
    title = Column(String, nullable=False)
    date_time = Column(DateTime, nullable=False)
    original_date = Column(DateTime, nullable=True)
    status = Column(String, default="pending")
    resident_email = Column(String, ForeignKey("clinic_user.email"), nullable=False)
    resident_name = Column(String, nullable=False)


    # ✅ Automatically managed timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    # 🆕 Professional note tracking (for dentist or system auto-notes)
    last_action = Column(String, nullable=True)
    last_action_by_role = Column(String, nullable=True)
    last_action_note = Column(Text, nullable=True)
    seen_by_resident = Column(Boolean, default=False)
