from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from config.database import SessionLocal
from models.user import User
from models.appointment import Appointment
from fastapi.templating import Jinja2Templates

router = APIRouter(prefix="/history", tags=["History"])
templates = Jinja2Templates(directory="templates")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/", response_class=HTMLResponse)
def history_page(request: Request, db: Session = Depends(get_db)):
    email = request.session.get("email")
    if not email:
        return HTMLResponse("<h2>Please log in first.</h2>", status_code=401)

    user = db.query(User).filter(User.email == email).first()
    if not user:
        return HTMLResponse("User not found", status_code=404)

    # ✅ Include all relevant statuses
    appointments = (
        db.query(Appointment)
        .filter(
            Appointment.resident_email == user.email,
            Appointment.status.in_(
                ["accepted", "completed", "cancelled", "rescheduled", "rejected"]
            ),
        )
        .order_by(Appointment.updated_at.desc())
        .all()
    )

    return templates.TemplateResponse(
        "history.html",
        {"request": request, "user": user, "appointments": appointments},
    )
