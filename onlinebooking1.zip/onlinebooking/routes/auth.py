from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from authlib.integrations.starlette_client import OAuth
from config.database import SessionLocal
from models.user import User
import os
from dotenv import load_dotenv
from fastapi import Form, status, Request


load_dotenv(".env")

router = APIRouter(prefix="/auth", tags=["Authentication"])

oauth = OAuth()
oauth.register(
    name="google",
    client_id=os.getenv("GOOGLE_CLIENT_ID"),
    client_secret=os.getenv("GOOGLE_CLIENT_SECRET"),
    server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
    client_kwargs={"scope": "openid email profile"},
)

@router.get("/login")
async def login_via_google(request: Request):
    return await oauth.google.authorize_redirect(request, os.getenv("GOOGLE_REDIRECT_URI"))

@router.get("/callback")
async def auth_callback(request: Request):
    token = await oauth.google.authorize_access_token(request)
    user_info = token.get("userinfo")

    if not user_info:
        return HTMLResponse("Failed to get user info", status_code=400)

    db = SessionLocal()
    user = db.query(User).filter(User.email == user_info["email"]).first()

    if not user:
        new_user = User(
            email=user_info["email"],
            name=user_info["name"],
            role="resident",
            picture=user_info.get("picture")
        )
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        user = new_user
    else:
        user.picture = user_info.get("picture")
        db.commit()

    request.session["email"] = user.email
    db.close()
    return RedirectResponse(url="/dashboard")

# --- Show Existing Account Login Form ---
@router.get("/existing-account", response_class=HTMLResponse)
async def existing_account_form():
    return """
    <html>
    <head>
        <title>Login to Existing Account</title>
        <link rel="stylesheet" href="/static/css/style.css">
    </head>
    <body>
        <div class="container">
            <img src="/static/img/dental logo.png" alt="Dental Clinic" class="logo">
            <h2>Login to Existing Account</h2>
            <p>Enter your email and password to login.</p>
            <form action="/auth/existing-account" method="post">
                <input type="email" name="email" placeholder="Email" required style="width: 100%; padding: 12px; margin-bottom: 15px; border-radius:5px; border:1px solid #ccc;">
                <input type="password" name="password" placeholder="Password" required style="width: 100%; padding: 12px; margin-bottom: 20px; border-radius:5px; border:1px solid #ccc;">
                <button type="submit" class="existing-btn">Login</button>
            </form>
        </div>
    </body>
    </html>
    """

# --- Handle Login Form Submission ---
@router.post("/existing-account")
async def existing_account_login(request: Request, email: str = Form(...), password: str = Form(...)):
    db = SessionLocal()
    user = db.query(User).filter(User.email == email, User.password == password).first()  # Update if using hashed passwords
    if not user:
        db.close()
        return HTMLResponse("Invalid email or password", status_code=status.HTTP_401_UNAUTHORIZED)

    request.session["email"] = user.email
    db.close()
    return RedirectResponse(url="/dashboard")