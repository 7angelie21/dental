# routes/dentist_unavailability.py
from fastapi import APIRouter, Depends, Request, HTTPException
from sqlalchemy.orm import Session
from models.unavailability import DentistUnavailability
from config.database import get_db

from utils import get_current_user

from pydantic import BaseModel

router = APIRouter(prefix="/api/dentist-unavailability", tags=["Dentist Unavailability"])

# Request body schema
class UnavailabilityCreate(BaseModel):
    start_date: str
    end_date: str | None = None
    start_time: str | None = None
    end_time: str | None = None

@router.post("/", status_code=201)
def create_unavailability(data: UnavailabilityCreate, request: Request, db: Session = Depends(get_db)):
    current_dentist = get_current_user(request, db)

    if current_dentist.role != "admin":  # or "dentist" if you prefer
        raise HTTPException(status_code=403, detail="Only dentists can set unavailability")

    new_block = DentistUnavailability(
        user_id=current_dentist.id,
        start_date=data.start_date,
        end_date=data.end_date,
        start_time=data.start_time,
        end_time=data.end_time
    )
    db.add(new_block)
    db.commit()
    db.refresh(new_block)
    return {"message": "Unavailability added", "id": new_block.id}
