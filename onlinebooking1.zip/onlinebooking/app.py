from flask import Flask, render_template
from api import slots_api
from models import Resident  # your SQLAlchemy model

app = Flask(__name__)
app.register_blueprint(slots_api)

@app.route('/')
def dashboard():
    # Fetch all residents from database
    residents = Resident.query.all()
    user = {"name": "Admin", "picture": None}
    return render_template('admin.html', user=user, residents=residents)

if __name__ == "__main__":
    app.run(debug=True)
